﻿Запуск приложения на локальном хосте http://127.0.0.1:5000.

Установить все зависимости из файла requirements_FLASK.txt в новое окружение.

I. С помощью файла app_py.ipynb:
   
	1) Открыть файл app_py.ipynb в Jupyter Notebook или Jupyrter Lab в окружении
	   созданном из файла requirements_FLASK.txt;
	2) Выполнить первую ячейку; 
        3) Перейти по ссылке.

II. С помощью консоли terminal:

	1) Запустить terminal в папке web_application в окружении созданном из файла requirements_FLASK.txt;
	2) Написать команду в terminal: "python app.py" и нажать клавишу Enter;
	3) Перейти по ссылке.