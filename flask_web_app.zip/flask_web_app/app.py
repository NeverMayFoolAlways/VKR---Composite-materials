import flask 
from flask import render_template
import pickle
import pandas as pd
import numpy as np

app = flask.Flask(__name__, template_folder = "templates")

@app.route("/", methods = ['POST', 'GET'])
def choose_prediction_method():
    return render_template('enter.html')

@app.route("/predict", methods = ["POST", "GET"])
def main():
    if flask.request.method == "GET":
        return render_template("main.html")
    
    if flask.request.method == "POST":
        
        with open("ela_regr_model.pkl", "rb") as f:
            loaded_model = pickle.load(f)
        
        f_mat = float(flask.request.form['fil_mat'])
        dens = float(flask.request.form['density'])
        m_tens = float(flask.request.form['mod_tens'])
        hard = float(flask.request.form['hard_qtty'])
        epox = float(flask.request.form['epoxide'])
        fl_temp = float(flask.request.form['flash_temp'])
        sur_dens = float(flask.request.form['surf_density'])
        t_str = float(flask.request.form['tens_str'])
        tar = float(flask.request.form['tar_cons'])
        angl = float(flask.request.form['str_angle'])
        step = float(flask.request.form['str_step'])
        s_dens = float(flask.request.form['str_density'])
        
        X_data = [[f_mat, dens, m_tens, hard, epox, fl_temp, sur_dens, t_str, tar, angl, step, s_dens]]
        X = pd.DataFrame(X_data, columns = ['Соотношение матрица-наполнитель', 'Плотность, кг/м3', 'модуль упругости, ГПа',
                                            'Количество отвердителя, м.%', 'Содержание эпоксидных групп,%_2', 'Температура вспышки, С_2',
                                            'Поверхностная плотность, г/м2', 'Прочность при растяжении, МПа', 'Потребление смолы, г/м2',
                                            'Угол нашивки, град', 'Шаг нашивки', 'Плотность нашивки'])
        
        y_pred = loaded_model.predict(X)
    
        return render_template("main.html", result = np.round(y_pred, 4))

if __name__ == "__main__":
    app.run()