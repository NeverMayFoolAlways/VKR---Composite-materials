from python_files.data import data
full_col_list = data.columns

# from python_files.full_col_list import full_col_list